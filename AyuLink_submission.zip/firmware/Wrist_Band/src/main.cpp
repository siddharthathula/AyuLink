/*
 * AyuLink Wristband — ESP32 DevKit
 * ====================================
 * Real Sensors: MAX30100 (HR/SpO2), MPU6500 (Fall — Adafruit MPU6050 lib is compatible)
 * OLED: SH1106 128x64 via U8g2
 * Comms: LoRa 433MHz → Gateway → Backend WebSocket
 * SOS: GPIO 33 hardware push button
 * GPS: Neo-6M (mock fallback if no satellite fix)
 */

#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <LoRa.h>
#include <TinyGPS++.h>
#include <ArduinoJson.h>
#include <U8g2lib.h>
#include "MAX30100_PulseOximeter.h"
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

// ─── OLED: SH1106 128x64 via U8g2 (Hardware I2C) ─────────
U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);

// ─── Pin Definitions ──────────────────────────────────────
#define PIN_BUTTON_SOS    33   // SOS push button (INPUT_PULLUP)
#define PIN_BUTTON_OK     32   // OK / Cancel button
#define PIN_LED_GREEN      4
#define PIN_LED_YELLOW    12
#define PIN_LED_RED       13
#define PIN_BUZZER        15
#define PIN_VIB_MOTOR     27

// ─── LoRa RA-02 ────────────────────────────────────────────
#define LORA_SCK  18
#define LORA_MISO 19
#define LORA_MOSI 23
#define LORA_NSS   5
#define LORA_RST  14
#define LORA_DIO0 26
#define LORA_BAND 433E6
#define NODE_ID "P_01"

// ─── GPS NEO-6M ───────────────────────────────────────────
#define GPS_RX 16
#define GPS_TX 17
// Mock location (Hanamkonda, Warangal) used when GPS has no fix
#define MOCK_LAT 18.0539
#define MOCK_LNG 79.5357

// ─── Timing ───────────────────────────────────────────────
#define SEND_INTERVAL_MS   3000
#define DISPLAY_CYCLE_MS   3000
#define POX_REPORT_MS      1000

// ─── Sensor Objects ───────────────────────────────────────
TinyGPSPlus      gps;
HardwareSerial   gpsSerial(2);
PulseOximeter    pox;
Adafruit_MPU6050 mpu;

// ─── State ────────────────────────────────────────────────
int   currentHR   = 0;
int   currentSpO2 = 0;
bool  isWorn      = true;
bool  isSOS       = false;
bool  isFall      = false;

// Fall detection state machine
bool          ff_triggered    = false;
bool          impact_detected = false;
unsigned long ff_ts           = 0;
unsigned long impact_ts       = 0;

// Button debounce
bool lastSosState = HIGH;
bool lastOkState  = HIGH;

// Display cycling
uint8_t       displayPage    = 0;
unsigned long lastDisplayMs  = 0;
unsigned long lastSendMs     = 0;
unsigned long lastPoxMs      = 0;

// Notification from backend (via LoRa downlink from Gateway)
String pendingNotification   = "";
unsigned long notifShowUntil = 0;

// ─── Helpers ──────────────────────────────────────────────
void beep(int ms) {
    digitalWrite(PIN_BUZZER, HIGH); delay(ms);
    digitalWrite(PIN_BUZZER, LOW);
}

void vibrate(int ms) {
    digitalWrite(PIN_VIB_MOTOR, HIGH); delay(ms);
    digitalWrite(PIN_VIB_MOTOR, LOW);
}

void setLED(bool r, bool y, bool g) {
    digitalWrite(PIN_LED_RED,    r ? HIGH : LOW);
    digitalWrite(PIN_LED_YELLOW, y ? HIGH : LOW);
    digitalWrite(PIN_LED_GREEN,  g ? HIGH : LOW);
}

// ─── U8g2 OLED Pages ──────────────────────────────────────
void drawOLED() {
    u8g2.clearBuffer();

    // Notification override
    if (millis() < notifShowUntil && pendingNotification.length() > 0) {
        u8g2.setFont(u8g2_font_6x10_tr);
        u8g2.drawStr(0, 10, ">> NOTIFICATION <<");
        // Word-wrap the message (max 21 chars/line at 6px font)
        u8g2.drawStr(0, 25, pendingNotification.substring(0, 21).c_str());
        if (pendingNotification.length() > 21)
            u8g2.drawStr(0, 37, pendingNotification.substring(21, 42).c_str());
        u8g2.sendBuffer();
        return;
    }

    // Emergency screen
    if (isSOS || isFall) {
        u8g2.setFont(u8g2_font_logisoso16_tr);
        u8g2.drawStr(10, 24, isFall ? "!! FALL !!" : "!! SOS !!");
        u8g2.setFont(u8g2_font_6x10_tr);
        u8g2.drawStr(0, 42, "EMERGENCY SENT");
        u8g2.drawStr(0, 55, "Press OK to cancel");
        u8g2.drawFrame(0, 0, 128, 64);
        u8g2.sendBuffer();
        return;
    }

    if (displayPage == 0) {
        // ── Page 0: Vitals ──
        u8g2.setFont(u8g2_font_6x10_tr);
        u8g2.drawStr(0, 10, "AyuLink Wristband");
        u8g2.drawHLine(0, 12, 128);

        u8g2.setFont(u8g2_font_logisoso16_tr);
        char buf[32];
        snprintf(buf, sizeof(buf), "HR %d", currentHR > 0 ? currentHR : 0);
        u8g2.drawStr(0, 34, buf);
        snprintf(buf, sizeof(buf), "O2 %d%%", currentSpO2 > 0 ? currentSpO2 : 0);
        u8g2.drawStr(0, 56, buf);

        u8g2.setFont(u8g2_font_6x10_tr);
        u8g2.drawStr(90, 20, isWorn ? "WORN" : "OFF");
    } else if (displayPage == 1) {
        // ── Page 1: GPS & Status ──
        u8g2.setFont(u8g2_font_6x10_tr);
        u8g2.drawStr(0, 10, "GPS & STATUS");
        u8g2.drawHLine(0, 12, 128);

        float lat = gps.location.isValid() ? gps.location.lat() : MOCK_LAT;
        float lng = gps.location.isValid() ? gps.location.lng() : MOCK_LNG;
        bool  fix = gps.location.isValid();

        char buf[32];
        snprintf(buf, sizeof(buf), "Lat: %.4f", lat);
        u8g2.drawStr(0, 26, buf);
        snprintf(buf, sizeof(buf), "Lng: %.4f", lng);
        u8g2.drawStr(0, 38, buf);
        u8g2.drawStr(0, 52, fix ? "GPS: LIVE FIX" : "GPS: MOCK LOC");
    }

    u8g2.sendBuffer();
}

// ─── LoRa Send ────────────────────────────────────────────
void sendVitals() {
    float lat = gps.location.isValid() ? gps.location.lat() : MOCK_LAT;
    float lng = gps.location.isValid() ? gps.location.lng() : MOCK_LNG;

    JsonDocument doc;
    doc["node"]  = NODE_ID;
    doc["hr"]    = currentHR;
    doc["oxy"]   = currentSpO2;
    doc["temp"]  = 0.0;   // No temp sensor on wristband — gateway provides ambient
    doc["lat"]   = lat;
    doc["lng"]   = lng;
    doc["sos"]   = isSOS;
    doc["fall"]  = isFall;
    doc["worn"]  = isWorn;

    String json;
    serializeJson(doc, json);
    LoRa.beginPacket();
    LoRa.print(json);
    LoRa.endPacket();

    Serial.print("[TX] "); Serial.println(json);
}

// ─── Fall Detection (Simplified for Stability) ────────────────────
void checkFall() {
    static unsigned long lastFallCheck = 0;
    if (millis() - lastFallCheck < 20) return; // 50Hz polling
    lastFallCheck = millis();

    sensors_event_t a, g, t;
    mpu.getEvent(&a, &g, &t);

    float ax = a.acceleration.x / 9.8f;
    float ay = a.acceleration.y / 9.8f;
    float az = a.acceleration.z / 9.8f;
    float total_g = sqrtf(ax*ax + ay*ay + az*az);

    // Stage 1: Detect a hard impact first
    // A real fall onto a hard surface generates > 3.0g, but for test-tapping the board we lower it to 1.8g
    if (total_g > 1.8f && !impact_detected) {
        impact_detected = true;
        impact_ts = millis();
    }

    // Stage 2: Wait 2 seconds and check for absolute stillness
    if (impact_detected) {
        if (millis() - impact_ts > 2000) {
            float gx = fabsf(g.gyro.x), gy = fabsf(g.gyro.y), gz = fabsf(g.gyro.z);
            
            // If the person is moving their arm around (gx, gy, gz > 0.5) or working (g != ~1)
            // they have recovered and are not incapacitated.
            if (gx < 0.5f && gy < 0.5f && gz < 0.5f && total_g > 0.8f && total_g < 1.3f) {
                Serial.println("[FALL CONFIRMED]");
                isFall = true;
                setLED(true, false, false);
                vibrate(1500);
                beep(500);
                sendVitals();  // Immediate TX
            } else {
                // False alarm, they are just moving
                Serial.println("[FALL REJECTED] Normal movement detected after impact.");
            }
            impact_detected = false; // Reset cycle
        }
    }
}

// ─── Button Handling ──────────────────────────────────────
void checkButtons() {
    bool sosNow = (digitalRead(PIN_BUTTON_SOS) == LOW);
    bool okNow  = (digitalRead(PIN_BUTTON_OK)  == LOW);

    // SOS button pressed (falling edge)
    if (sosNow && !lastSosState) {
        delay(50);  // debounce
        if (digitalRead(PIN_BUTTON_SOS) == LOW) {
            isSOS = !isSOS;
            if (isSOS) {
                isFall = false;
                setLED(true, false, false);
                vibrate(500); beep(200);
                Serial.println("[SOS ACTIVATED]");
            } else {
                setLED(false, false, true);
                Serial.println("[SOS DEACTIVATED]");
            }
            sendVitals();  // Immediate TX
        }
    }

    // OK button: cancel SOS / fall
    if (okNow && !lastOkState) {
        delay(50);
        if (digitalRead(PIN_BUTTON_OK) == LOW) {
            if (isSOS || isFall) {
                isSOS  = false;
                isFall = false;
                setLED(false, false, true);
                beep(100);
                sendVitals();
                Serial.println("[EMERGENCY CANCELLED]");
            }
        }
    }

    lastSosState = sosNow;
    lastOkState  = okNow;
}

// ─── MAX30100 Callback ────────────────────────────────────
void onBeatDetected() {
    Serial.println("[POX] Beat");
}

// ─── Setup ────────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    Wire.begin();
    Wire.setClock(100000); // Enforce standard 100KHz for MAX30100 purple board compatibility

    // Pin modes
    pinMode(PIN_BUTTON_SOS, INPUT_PULLUP);
    pinMode(PIN_BUTTON_OK,  INPUT_PULLUP);
    pinMode(PIN_LED_GREEN,  OUTPUT);
    pinMode(PIN_LED_YELLOW, OUTPUT);
    pinMode(PIN_LED_RED,    OUTPUT);
    pinMode(PIN_BUZZER,     OUTPUT);
    pinMode(PIN_VIB_MOTOR,  OUTPUT);
    setLED(false, false, false);

    // OLED init
    u8g2.begin();
    u8g2.clearBuffer();
    u8g2.setFont(u8g2_font_6x10_tr);
    u8g2.drawStr(0, 10, "AyuLink Starting...");
    u8g2.sendBuffer();

    // GPS
    gpsSerial.begin(9600, SERIAL_8N1, GPS_RX, GPS_TX);

    // MAX30100
    Serial.print("[POX] Init...");
    if (!pox.begin()) {
        Serial.println(" FAILED");
    } else {
        pox.setOnBeatDetectedCallback(onBeatDetected);
        pox.setIRLedCurrent(MAX30100_LED_CURR_24MA); // Purple board sweet spot (50mA browns out the 1.8v regular, 7.6mA is too dim)
        Serial.println(" OK");
    }

    // MPU6050
    Serial.print("[MPU] Init...");
    if (!mpu.begin()) {
        Serial.println(" FAILED");
    } else {
        mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
        mpu.setGyroRange(MPU6050_RANGE_500_DEG);
        mpu.setFilterBandwidth(MPU6050_BAND_5_HZ); // Smooth out high-frequency noise
        Serial.println(" OK");
    }

    // LoRa
    SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_NSS);
    LoRa.setPins(LORA_NSS, LORA_RST, LORA_DIO0);
    if (!LoRa.begin(LORA_BAND)) {
        Serial.println("[LoRa] FAILED");
        while (1) { beep(100); delay(200); }
    }
    LoRa.setSpreadingFactor(7);
    Serial.println("[LoRa] OK");

    setLED(false, false, true);
    beep(150);

    u8g2.clearBuffer();
    u8g2.setFont(u8g2_font_6x10_tr);
    u8g2.drawStr(0, 10, "AyuLink READY");
    u8g2.drawStr(0, 25, "NODE: " NODE_ID);
    u8g2.sendBuffer();
    delay(1000);
}

// ─── Loop ─────────────────────────────────────────────────
void loop() {
    unsigned long now = millis();

    // MAX30100 update
    pox.update();
    if (now - lastPoxMs > POX_REPORT_MS) {
        lastPoxMs = now;
        int hr   = (int)pox.getHeartRate();
        int spo2 = (int)pox.getSpO2();
        if (hr > 20 && hr < 250)    currentHR   = hr;
        if (spo2 > 50 && spo2 < 101) currentSpO2 = spo2;
        isWorn = (hr > 0 || spo2 > 0);
    }

    // GPS update
    while (gpsSerial.available()) gps.encode(gpsSerial.read());

    // Fall detection
    checkFall();

    // Buttons
    checkButtons();

    // Check for LoRa downlink (notification from Gateway)
    int pkSize = LoRa.parsePacket();
    if (pkSize) {
        String incoming = "";
        while (LoRa.available()) incoming += (char)LoRa.read();
        Serial.print("[RX] "); Serial.println(incoming);

        JsonDocument rDoc;
        if (!deserializeJson(rDoc, incoming)) {
            String cmd = rDoc["cmd"] | "";
            if (cmd == "clear" || rDoc["clear"]) {
                pendingNotification = "";
                notifShowUntil = 0;
                Serial.println("[CLEAR] OLED notification cleared");
            } else if (rDoc["notif"]) {
                pendingNotification = rDoc["notif"].as<String>();
                notifShowUntil = millis() + 8000;
                vibrate(300); beep(100);
                Serial.println("[NOTIF] " + pendingNotification);
            }
        }
    }

    // Periodic LoRa TX
    if (now - lastSendMs > SEND_INTERVAL_MS) {
        lastSendMs = now;
        sendVitals();

        // LED heartbeat
        if (!isSOS && !isFall) {
            setLED(false, false, true);
            delay(50);
            setLED(false, false, false);
        }
    }

    // OLED cycle (Paced to avoid blocking MAX30100 FIFO drains)
    static unsigned long lastOledDrawMs = 0;
    if (now - lastDisplayMs > DISPLAY_CYCLE_MS) {
        lastDisplayMs = now;
        if (!isSOS && !isFall && millis() >= notifShowUntil)
            displayPage = (displayPage + 1) % 2;
    }
    
    // Only draw at ~10 FPS max so we don't stall the pulse oximeter
    if (now - lastOledDrawMs > 100 || isSOS || isFall) {
        drawOLED();
        lastOledDrawMs = now;
    }

    // Emergency LED strobe
    if (isSOS || isFall) {
        static unsigned long lastStrobe = 0;
        static bool strobeState = false;
        if (now - lastStrobe > 200) {
            strobeState = !strobeState;
            lastStrobe = now;
            digitalWrite(PIN_LED_RED, strobeState ? HIGH : LOW);
            digitalWrite(PIN_BUZZER,  strobeState ? HIGH : LOW);
        }
    }
}
