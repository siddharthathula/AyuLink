/**
 * AyuLink ESP32-CAM — MJPEG Stream Server
 * Hardware: AI-Thinker ESP32-CAM
 * Stream:   http://<IP>:81/stream   or   http://ayulink-cam.local:81/stream
 *
 * WiFi: "WiFi" / "wordpass"  (mobile hotspot, laptop on same network)
 * CORS: enabled (browser can load stream directly)
 */

#include <WiFi.h>
#include <ESPmDNS.h>
#include "esp_camera.h"
#include "esp_http_server.h"
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

// ─── WiFi ──────────────────────────────────────────────────────────────────
const char* WIFI_SSID = "WiFi";
const char* WIFI_PASS = "wordpass";
const char* MDNS_HOST = "ayulink-cam";  // accessible as ayulink-cam.local

// ─── AI-Thinker ESP32-CAM Pinout ───────────────────────────────────────────
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22
#define FLASH_LED_PIN      4  // Built-in flash LED

// ─── MJPEG stream constants ─────────────────────────────────────────────────
#define PART_BOUNDARY "ayulinkframe"
static const char* STREAM_CONTENT_TYPE =
    "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char* STREAM_BOUNDARY = "\r\n--" PART_BOUNDARY "\r\n";
static const char* STREAM_PART     = "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

httpd_handle_t stream_httpd = NULL;

// ─── MJPEG frame sender ─────────────────────────────────────────────────────
static esp_err_t stream_handler(httpd_req_t* req) {
    camera_fb_t* fb  = NULL;
    esp_err_t    res = ESP_OK;
    size_t       jpg_len;
    uint8_t*     jpg_buf;
    char         part_buf[64];

    httpd_resp_set_type(req, STREAM_CONTENT_TYPE);
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
    httpd_resp_set_hdr(req, "Access-Control-Allow-Methods", "GET");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store, no-cache, must-revalidate");
    httpd_resp_set_hdr(req, "X-Content-Type-Options", "nosniff");

    Serial.println("[CAM] Client connected to /stream");

    while (res == ESP_OK) {
        fb = esp_camera_fb_get();
        if (!fb) {
            Serial.println("[CAM] Frame capture failed – skipping");
            delay(50);
            continue;
        }

        // Convert non-JPEG frames
        bool needs_free = false;
        if (fb->format != PIXFORMAT_JPEG) {
            bool ok = frame2jpg(fb, 80, &jpg_buf, &jpg_len);
            esp_camera_fb_return(fb);
            fb = NULL;
            if (!ok) { res = ESP_FAIL; break; }
            needs_free = true;
        } else {
            jpg_len = fb->len;
            jpg_buf = fb->buf;
        }

        // Send boundary
        res = httpd_resp_send_chunk(req, STREAM_BOUNDARY, strlen(STREAM_BOUNDARY));

        // Send part header
        if (res == ESP_OK) {
            size_t hlen = snprintf(part_buf, sizeof(part_buf), STREAM_PART, jpg_len);
            res = httpd_resp_send_chunk(req, part_buf, hlen);
        }

        // Send JPEG data
        if (res == ESP_OK)
            res = httpd_resp_send_chunk(req, (const char*)jpg_buf, jpg_len);

        // Free frame buffer
        if (fb)  { esp_camera_fb_return(fb); fb = NULL; }
        if (needs_free) { free(jpg_buf); }
    }

    Serial.println("[CAM] Client disconnected from /stream");
    return res;
}

// ─── Root / health check ─────────────────────────────────────────────────────
static esp_err_t root_handler(httpd_req_t* req) {
    char html[512];
    snprintf(html, sizeof(html),
        "<html><body style='font-family:monospace;background:#111;color:#0f0;padding:2rem'>"
        "<h2>AyuLink ESP32-CAM</h2>"
        "<p>Status: <b>ONLINE</b></p>"
        "<p>Stream: <a href='/stream' style='color:#0af'>http://%s:81/stream</a></p>"
        "<p>mDNS:   <a href='http://%s.local:81/stream' style='color:#0af'>"
        "http://%s.local:81/stream</a></p>"
        "</body></html>",
        WiFi.localIP().toString().c_str(),
        MDNS_HOST,
        MDNS_HOST
    );
    httpd_resp_set_type(req, "text/html");
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
    httpd_resp_send(req, html, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

// ─── Start HTTP server ───────────────────────────────────────────────────────
void startStreamServer() {
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.server_port      = 81;
    cfg.max_uri_handlers = 4;
    cfg.stack_size       = 8192;
    cfg.lru_purge_enable = true;

    httpd_uri_t stream_uri = { "/stream", HTTP_GET, stream_handler, NULL };
    httpd_uri_t root_uri   = { "/",       HTTP_GET, root_handler,   NULL };

    if (httpd_start(&stream_httpd, &cfg) == ESP_OK) {
        httpd_register_uri_handler(stream_httpd, &stream_uri);
        httpd_register_uri_handler(stream_httpd, &root_uri);
        Serial.println("[CAM] HTTP server started on port 81");
    } else {
        Serial.println("[CAM] FAILED to start HTTP server!");
    }
}

// ─── Camera init ─────────────────────────────────────────────────────────────
bool initCamera() {
    camera_config_t cfg;
    cfg.ledc_channel  = LEDC_CHANNEL_0;
    cfg.ledc_timer    = LEDC_TIMER_0;
    cfg.pin_d0 = Y2_GPIO_NUM; cfg.pin_d1 = Y3_GPIO_NUM;
    cfg.pin_d2 = Y4_GPIO_NUM; cfg.pin_d3 = Y5_GPIO_NUM;
    cfg.pin_d4 = Y6_GPIO_NUM; cfg.pin_d5 = Y7_GPIO_NUM;
    cfg.pin_d6 = Y8_GPIO_NUM; cfg.pin_d7 = Y9_GPIO_NUM;
    cfg.pin_xclk    = XCLK_GPIO_NUM;
    cfg.pin_pclk    = PCLK_GPIO_NUM;
    cfg.pin_vsync   = VSYNC_GPIO_NUM;
    cfg.pin_href    = HREF_GPIO_NUM;
    cfg.pin_sccb_sda = SIOD_GPIO_NUM;
    cfg.pin_sccb_scl = SIOC_GPIO_NUM;
    cfg.pin_pwdn    = PWDN_GPIO_NUM;
    cfg.pin_reset   = RESET_GPIO_NUM;
    cfg.xclk_freq_hz = 20000000;
    cfg.pixel_format = PIXFORMAT_JPEG;
    cfg.grab_mode    = CAMERA_GRAB_LATEST;  // always get newest frame

    if (psramFound()) {
        cfg.frame_size   = FRAMESIZE_VGA;   // 640x480 — good quality
        cfg.jpeg_quality = 12;              // 0=best, 63=worst
        cfg.fb_count     = 2;
        cfg.fb_location  = CAMERA_FB_IN_PSRAM;
        Serial.println("[CAM] PSRAM found → VGA (640x480)");
    } else {
        cfg.frame_size   = FRAMESIZE_QVGA;  // 320x240 — safe without PSRAM
        cfg.jpeg_quality = 20;
        cfg.fb_count     = 1;
        cfg.fb_location  = CAMERA_FB_IN_DRAM;
        Serial.println("[CAM] No PSRAM → QVGA (320x240)");
    }

    esp_err_t err = esp_camera_init(&cfg);
    if (err != ESP_OK) {
        Serial.printf("[CAM] Init FAILED: 0x%x\n", err);
        return false;
    }

    // Sensor tuning
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_vflip(s, 0);       // flip vertical if camera is upside down: set to 1
        s->set_hmirror(s, 0);     // horizontal mirror
        s->set_brightness(s, 1);  // slight brightness boost
        s->set_saturation(s, 0);
        s->set_contrast(s, 1);
        s->set_whitebal(s, 1);    // auto white balance
        s->set_awb_gain(s, 1);
    }
    return true;
}

// ─── WiFi connect with retry ─────────────────────────────────────────────────
void connectWiFi() {
    Serial.printf("\n[WiFi] Connecting to \"%s\"", WIFI_SSID);
    WiFi.mode(WIFI_STA);
    WiFi.setSleep(false);
    WiFi.begin(WIFI_SSID, WIFI_PASS);

    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 30) {
        delay(500);
        Serial.print(".");
        attempts++;
    }

    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\n[WiFi] Connected!");
        Serial.printf("[WiFi] IP Address: %s\n", WiFi.localIP().toString().c_str());
        Serial.printf("[WiFi] Signal:      %d dBm\n", WiFi.RSSI());
    } else {
        Serial.println("\n[WiFi] FAILED — will retry in loop");
    }
}

// ─── Setup ───────────────────────────────────────────────────────────────────
void setup() {
    WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0);  // disable brownout detector

    Serial.begin(115200);
    delay(200);
    Serial.println("\n\n========================================");
    Serial.println("   AyuLink ESP32-CAM  —  Starting...");
    Serial.println("========================================");

    // Flash LED pin setup
    pinMode(FLASH_LED_PIN, OUTPUT);
    digitalWrite(FLASH_LED_PIN, LOW);

    // Init camera
    if (!initCamera()) {
        Serial.println("[CAM] Camera init failed! Blinking error LED...");
        while (true) {
            digitalWrite(FLASH_LED_PIN, HIGH); delay(200);
            digitalWrite(FLASH_LED_PIN, LOW);  delay(200);
        }
    }
    Serial.println("[CAM] Camera OK");

    // Connect WiFi
    connectWiFi();

    // mDNS — access camera at http://ayulink-cam.local:81/stream
    if (WiFi.status() == WL_CONNECTED) {
        if (MDNS.begin(MDNS_HOST)) {
            MDNS.addService("http", "tcp", 81);
            Serial.printf("[mDNS] Hostname: http://%s.local:81/stream\n", MDNS_HOST);
        }
    }

    // Start stream server
    startStreamServer();

    // ── Print connection info ──
    Serial.println("\n========================================");
    Serial.printf("  📷 STREAM URL:  http://%s:81/stream\n", WiFi.localIP().toString().c_str());
    Serial.printf("  🌐 mDNS URL:    http://%s.local:81/stream\n", MDNS_HOST);
    Serial.println("  → Enter this IP in AyuLink Dashboard Camera widget");
    Serial.println("========================================\n");

    // Brief flash to confirm ready
    digitalWrite(FLASH_LED_PIN, HIGH); delay(300);
    digitalWrite(FLASH_LED_PIN, LOW);
}

// ─── Loop — maintain WiFi, nothing else needed ───────────────────────────────
void loop() {
    // Reconnect WiFi if dropped
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("[WiFi] Lost connection — reconnecting...");
        WiFi.reconnect();
        delay(5000);
        if (WiFi.status() == WL_CONNECTED) {
            Serial.printf("[WiFi] Reconnected! IP: %s\n", WiFi.localIP().toString().c_str());
            // Brief flash to confirm reconnect
            digitalWrite(FLASH_LED_PIN, HIGH); delay(100);
            digitalWrite(FLASH_LED_PIN, LOW);
        }
    }
    delay(5000);  // check WiFi every 5s — stream runs in its own task
}
