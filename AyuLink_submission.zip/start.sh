#!/bin/bash
# AyuLink Auto-Start & Watchdog
# Starts backend + frontend and auto-restarts if either crashes

ROOTDIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$ROOTDIR/backend"
FRONTEND_DIR="$ROOTDIR/frontend"
LOG_DIR="$ROOTDIR/logs"
mkdir -p "$LOG_DIR"

# Colors
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

echo -e "${CYAN}╔══════════════════════════════════════╗${NC}"
echo -e "${CYAN}║    AyuLink IoT Monitor — AutoStart   ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════╝${NC}"

# Kill anything on our ports cleanly
cleanup() {
    echo -e "\n${YELLOW}Shutting down AyuLink...${NC}"
    kill $BACKEND_PID $FRONTEND_PID 2>/dev/null
    wait $BACKEND_PID $FRONTEND_PID 2>/dev/null
    exit 0
}
trap cleanup SIGINT SIGTERM

# ── Backend Watchdog ──────────────────────────────────────────────────────────
run_backend() {
    while true; do
        echo -e "${GREEN}[$(date +%H:%M:%S)] Starting backend...${NC}"
        fuser -k 8000/tcp 2>/dev/null
        sleep 1
        cd "$BACKEND_DIR"
        python3 -m uvicorn main:app --host 0.0.0.0 --port 8000 \
            >> "$LOG_DIR/backend.log" 2>&1
        EXIT=$?
        echo -e "${RED}[$(date +%H:%M:%S)] Backend exited (code $EXIT). Restarting in 3s...${NC}" | tee -a "$LOG_DIR/backend.log"
        sleep 3
    done
}

# ── Frontend Watchdog ─────────────────────────────────────────────────────────
run_frontend() {
    while true; do
        echo -e "${GREEN}[$(date +%H:%M:%S)] Starting frontend...${NC}"
        fuser -k 3000/tcp 2>/dev/null
        sleep 1
        cd "$FRONTEND_DIR"
        npm run dev >> "$LOG_DIR/frontend.log" 2>&1
        EXIT=$?
        echo -e "${RED}[$(date +%H:%M:%S)] Frontend exited (code $EXIT). Restarting in 3s...${NC}" | tee -a "$LOG_DIR/frontend.log"
        sleep 3
    done
}

# ── Start both in background ──────────────────────────────────────────────────
run_backend &
BACKEND_PID=$!

run_frontend &
FRONTEND_PID=$!

echo -e "${GREEN}✓ Backend watchdog PID: $BACKEND_PID${NC}"
echo -e "${GREEN}✓ Frontend watchdog PID: $FRONTEND_PID${NC}"
echo -e "${YELLOW}Logs: $LOG_DIR/${NC}"
echo -e "${CYAN}Dashboard: http://localhost:3000${NC}"
echo -e "${CYAN}Backend:   http://localhost:8000${NC}"
echo -e "\nPress Ctrl+C to stop all services.\n"

# ── Health Monitor (prints status every 30s) ──────────────────────────────────
while true; do
    sleep 30
    # Check backend
    if curl -sf http://localhost:8000/api/status > /dev/null 2>&1; then
        BSTATUS="${GREEN}✓ UP${NC}"
    else
        BSTATUS="${RED}✗ DOWN${NC}"
    fi
    # Check frontend
    if curl -sf http://localhost:3000 > /dev/null 2>&1; then
        FSTATUS="${GREEN}✓ UP${NC}"
    else
        FSTATUS="${RED}✗ DOWN${NC}"
    fi
    echo -e "[$(date +%H:%M:%S)] Backend: $BSTATUS  |  Frontend: $FSTATUS"
done
