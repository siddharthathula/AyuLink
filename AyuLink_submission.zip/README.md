# 🩺 AyuLink — Remote Patient Monitoring (IoT) Agent
**Hackathon Challenge #26 · Healthcare · Real-time IoT Monitoring**

> An intelligent agent that continuously monitors real-time heart rate, blood pressure, and vitals data streams from wearable IoT devices and automatically triggers emergency alerts when values exceed clinically dangerous thresholds.

---

## 🏗️ System Architecture

```
┌───────────────────────────────────────────────────────────────┐
│                        PATIENT LAYER                          │
│                                                               │
│  ┌──────────────────────────────────────────────────┐        │
│  │  AyuLink Wristband (ESP32 Dev Kit)                │        │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐          │        │
│  │  │MAX30100  │ │ MPU6500  │ │ Neo-6M   │          │        │
│  │  │HR + SpO2 │ │  Fall    │ │  GPS     │          │        │
│  │  └──────────┘ └──────────┘ └──────────┘          │        │
│  │  ┌──────────────────────┐  ┌──────────┐          │        │
│  │  │  SH1106 OLED Display │  │SOS Button│          │        │
│  │  └──────────────────────┘  └──────────┘          │        │
│  │         │ LoRa RA-02 (433MHz)                     │        │
│  └─────────┼────────────────────────────────────────┘        │
│            │ LoRa RF (up to 2km range)                        │
└────────────┼──────────────────────────────────────────────────┘
             │
┌────────────▼──────────────────────────────────────────────────┐
│                       GATEWAY LAYER                            │
│                                                                │
│  ┌──────────────────────────────────────────────────┐         │
│  │  AyuLink Gateway (ESP32 Dev Kit)                  │         │
│  │  ┌──────────────┐  ┌──────────┐  ┌───────────┐  │         │
│  │  │  LoRa RA-02  │  │SH1106    │  │ DHT22     │  │         │
│  │  │  (Receiver)  │  │OLED      │  │ Env Sensor│  │         │
│  │  └──────────────┘  └──────────┘  └───────────┘  │         │
│  │         │ WiFi WebSocket (ws://backend:8000)      │         │
│  └─────────┼────────────────────────────────────────┘         │
│            │ WiFi (192.168.x.x)                                │
└────────────┼──────────────────────────────────────────────────┘
             │
┌────────────▼──────────────────────────────────────────────────┐
│                       BACKEND LAYER (Python)                   │
│                                                                │
│  FastAPI Server (port 8000)                                    │
│  ┌──────────────────────────────────────────────────────┐     │
│  │  ThresholdEngine        AyuAgent (Groq LLM)           │     │
│  │  ┌────────────────┐    ┌──────────────────────────┐  │     │
│  │  │ HR > 120 → 🚨  │    │ llama-3.3-70b-versatile  │  │     │
│  │  │ SpO2 < 90% → 🚨│    │ Auto-triage on alerts    │  │     │
│  │  │ BP > 180 → 🚨  │    │ Multi-language (EN/HI/TE)│  │     │
│  │  │ Fall → 🚨       │    └──────────────────────────┘  │     │
│  │  │ SOS → 🚨        │                                   │     │
│  │  └────────────────┘    MockDataStream (demo mode)      │     │
│  │                        SQLite Database (ayulink.db)     │     │
│  └──────────────────────────────────────────────────────┘     │
│         │ WebSocket broadcast to all dashboard clients         │
└─────────┼──────────────────────────────────────────────────────┘
          │
┌─────────▼──────────────────────────────────────────────────────┐
│                      DASHBOARD LAYER (Next.js)                  │
│                                                                  │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Main        │  │ AI Agent     │  │ Family Portal         │  │
│  │ Dashboard   │  │ Chat (Groq)  │  │ (Real-time alerts)    │  │
│  └─────────────┘  └──────────────┘  └──────────────────────┘  │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Emergency   │  │ Patients     │  │ Notifications         │  │
│  │ Dispatch    │  │ Records      │  │ System                │  │
│  └─────────────┘  └──────────────┘  └──────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🎯 Key Objectives — Implementation Status

| Objective | Implementation |
|---|---|
| ✅ Monitor vitals in real-time | WebSocket stream at 3s intervals from IoT hardware + mock stream |
| ✅ Detect critical value crossings | `ThresholdEngine` with HR, SpO2, Blood Pressure, Temp, Fall, SOS |
| ✅ Trigger emergency alerts instantly | Sub-100ms WebSocket broadcast to all dashboards on threshold breach |
| ✅ Reduce critical event response time | Groq LLM auto-triage fires AI analysis instantly on every alert |

---

## 📋 Requirements — Implementation

### 1. Mock IoT Data Stream (`backend/mock_stream.py`)
- `MockPatientProfile` simulates realistic vitals with natural variation (`sin()` wave + noise)
- Simulates cardiac events (HR 130-160, BP 170-200/110-130), falls, SOS, device removal
- Patient conditions (Hypertension, COPD, Cardiac) affect baseline vitals
- Blood pressure baseline: Normal 120/80 → Hypertensive patient 145/95

### 2. Real-time Threshold Monitoring (`backend/threshold_engine.py`)

| Vital | Warning | Critical |
|---|---|---|
| Heart Rate | >100 or <55 bpm | >120 or <40 bpm |
| SpO2 | <94% | <90% |
| Temperature | >38°C | >39°C or <35°C |
| BP Systolic | ≥140 mmHg | ≥180 mmHg (crisis) |
| BP Diastolic | ≥90 mmHg | ≥120 mmHg (crisis) |
| Fall Detected | — | EMERGENCY |
| SOS Button | — | EMERGENCY |
| Air Quality | >150 PPM | >300 PPM |
| Flame | — | EMERGENCY |

### 3. Emergency Alert Dispatch (`backend/main.py`)
- Alerts broadcast via WebSocket to ALL connected dashboard clients simultaneously
- Groq LLM (`AyuAgent`) auto-analyzes each alert and generates AI triage insight
- Gateway OLED display overrides to emergency screen (hardware alert)
- Wristband buzzer fires for local patient feedback

### 4. Patient & Doctor Notification System
- `/api/notifications` — send multilingual (EN/HI/TE) messages to patients
- `/api/dispatch` — fire paramedic dispatch with GPS coordinates
- Family Portal — real-time WebSocket alerts to family members
- AI chat interface for doctor queries in natural language

---

## 🚀 Quick Start

### Backend
```bash
cd backend
pip install -r requirements.txt
# Set GROQ_API_KEY in .env
fastapi dev main.py
```

### Frontend
```bash
cd frontend
npm install
npm run dev
# Open http://localhost:3000
```

### Firmware (PlatformIO)
```bash
# Upload Wristband
cd firmware/Wrist_Band && pio run -t upload

# Upload Gateway
cd firmware/Gateway && pio run -t upload
```

---

## 🏅 Deliverables Checklist

- [x] **IoT Monitoring Agent** — `backend/ai_agent.py` + `backend/threshold_engine.py`
- [x] **Real-time Vitals Dashboard** — `frontend/app/dashboard/` + WebSocket stream
- [x] **Alert Simulation** — `/api/simulate/sos`, `/cardiac`, `/fall`, `/flame` endpoints
- [x] **System Architecture Documentation** — This README
- [x] **Blood Pressure Monitoring** — `bp_systolic`/`bp_diastolic` in full stack

---

## 🔧 Tech Stack

| Layer | Technology |
|---|---|
| IoT Hardware | ESP32, MAX30100, MPU6500, Neo-6M GPS, LoRa RA-02 |
| Communication | LoRa 433MHz (IoT) + WiFi WebSocket (gateway→backend) |
| Backend | Python, FastAPI, WebSockets, SQLite |
| AI Agent | Groq API (llama-3.3-70b-versatile) |
| Frontend | Next.js 15, Tailwind CSS, WebSockets |
| Database | SQLite (local, offline-capable) |
