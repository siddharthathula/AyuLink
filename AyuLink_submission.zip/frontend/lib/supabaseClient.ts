import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

const isSupabaseConfigured = supabaseUrl && supabaseUrl.startsWith('http') && supabaseAnonKey && !supabaseUrl.includes('your_supabase_url')

// Mock client for development/demo when credentials are missing
// In-memory store for mocks
const mockStore: Record<string, any[]> = {
    patients: [
        { id: 'P-001', name: 'Ramulu Goud', village: 'Shadnagar', status: 'normal' },
        { id: 'P-002', name: 'Laxmi Narsamma', village: 'Maheshwaram', status: 'normal' },
        { id: 'P-003', name: 'Srinivas Reddy', village: 'Shamshabad', status: 'offline' },
        { id: 'P-004', name: 'Buchamma', village: 'Chevella', status: 'normal' },
        { id: 'P-005', name: 'Venkat Rao', village: 'Ibrahimpatnam', status: 'normal' },
    ],
    vitals: [],
    patient_records: [],
    asha_visits: [
        { id: 'V-001', patient_id: 'P-001', asha_name: 'Swarupa', scheduled_time: '2023-10-27T09:00:00', status: 'completed', type: 'routine' },
        { id: 'V-002', patient_id: 'P-002', asha_name: 'Kavitha', scheduled_time: '2023-10-27T10:30:00', status: 'pending', type: 'emergency' },
        { id: 'V-003', patient_id: 'P-003', asha_name: 'Manjula', scheduled_time: '2023-10-27T14:00:00', status: 'pending', type: 'routine' }
    ]
}

// Mock client for development/demo when credentials are missing
const mockSupabase = {
    from: (table: string) => {
        const chain = {
            select: () => chain,
            order: () => chain,
            limit: () => chain,
            eq: () => chain,
            insert: (data: any) => {
                const rows = Array.isArray(data) ? data : [data]
                if (!mockStore[table]) mockStore[table] = []
                // Add fake IDs if missing
                const recordsWithId = rows.map(r => ({
                    id: Math.random().toString(36).substr(2, 9),
                    created_at: new Date().toISOString(),
                    ...r
                }))
                mockStore[table].push(...recordsWithId)
                console.log(`[Mock] Inserted into ${table}:`, recordsWithId)
                return Promise.resolve({ data: recordsWithId, error: null })
            },
            update: (data: any) => {
                console.log(`[Mock] Updated ${table}:`, data)
                return Promise.resolve({ data: [data], error: null })
            },
            delete: () => {
                const deleteChain = {
                    eq: (col: string, val: any) => {
                        console.log(`[Mock] Deleted from ${table} where ${col} = ${val}`)
                        mockStore[table] = (mockStore[table] || []).filter(item => item[col] !== val)
                        return Promise.resolve({ data: [], error: null })
                    }
                }
                return deleteChain
            },
            // Allow awaiting the chain
            then: (onfulfilled: any) => {
                console.log(`[Mock] Resolving query for ${table}`)
                return Promise.resolve({ data: mockStore[table] || [], error: null }).then(onfulfilled)
            }
        }
        return chain
    },
    storage: {
        from: (bucket: string) => ({
            upload: (path: string, file: any) => {
                console.log(`[Mock] Uploaded to ${bucket}/${path}`, file)
                if (typeof window !== 'undefined') {
                    (window as any)._mockStorage = (window as any)._mockStorage || {};
                    (window as any)._mockStorage[`${bucket}/${path}`] = file;
                }
                return Promise.resolve({ data: { path }, error: null })
            },
            getPublicUrl: (path: string) => {
                console.log(`[Mock] Generating public URL for ${bucket}/${path}`)
                if (typeof window !== 'undefined' && (window as any)._mockStorage) {
                    const file = (window as any)._mockStorage[`${bucket}/${path}`];
                    if (file) return { data: { publicUrl: URL.createObjectURL(file) } };
                }
                return { data: { publicUrl: `https://placehold.co/600x400?text=${encodeURIComponent(path)}` } }
            },
            remove: (paths: string[]) => {
                console.log(`[Mock] Removed from ${bucket}:`, paths)
                if (typeof window !== 'undefined' && (window as any)._mockStorage) {
                    paths.forEach(p => delete (window as any)._mockStorage[`${bucket}/${p}`]);
                }
                return Promise.resolve({ data: [], error: null })
            }
        })
    },
    auth: {
        getSession: () => Promise.resolve({ data: { session: null }, error: null }),
        onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => { } } } }),
    },
    channel: (name: string) => {
        const channelObj = {
            on: (type: string, filter: any, callback: any) => {
                const handler = (e: any) => {
                    if (e.detail.name === name && e.detail.event === filter.event) {
                        callback(e.detail.payload)
                    }
                }
                if (typeof window !== 'undefined') {
                    window.addEventListener('supabase-mock-broadcast', handler)
                }
                return channelObj
            },
            subscribe: () => channelObj,
            unsubscribe: () => { },
            send: (payload: any) => {
                console.log(`[Mock Supabase] Sending to ${name}:`, payload)
                if (typeof window !== 'undefined') {
                    window.dispatchEvent(new CustomEvent('supabase-mock-broadcast', {
                        detail: { name, event: payload.event, payload }
                    }))
                }
                return Promise.resolve('ok')
            }
        }
        return channelObj
    },
    removeChannel: () => Promise.resolve(),
}

// Export real client if configured, otherwise mock
export const supabase = isSupabaseConfigured
    ? createClient(supabaseUrl!, supabaseAnonKey!)
    : mockSupabase as any

// Helper to check if we are using the real backend
export const isSupabaseLive = !!isSupabaseConfigured
