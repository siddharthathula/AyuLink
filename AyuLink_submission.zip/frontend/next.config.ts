import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  allowedDevOrigins: ["10.121.171.237:3000"],
  async rewrites() {
    return [
      {
        // Exclude cam-proxy – it's handled by Next.js locally
        source: '/api/:path((?!cam-proxy).*)',
        destination: 'http://127.0.0.1:8000/api/:path*',
      },
    ]
  },
};

export default nextConfig;
