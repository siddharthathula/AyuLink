"""
AyuLink IoT Monitoring Agent — Configuration
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ── Network ──────────────────────────────────────────────
WIFI_SSID = "WiFi"
WIFI_PASS = "wordpass"
GATEWAY_IP = os.getenv("GATEWAY_IP", "192.168.4.1")
GATEWAY_WS_PORT = 81
GATEWAY_WS_URL = f"ws://{GATEWAY_IP}:{GATEWAY_WS_PORT}"

BACKEND_HOST = "0.0.0.0"
BACKEND_PORT = 8000

# ── Thresholds ───────────────────────────────────────────
HR_WARNING_HIGH = 100
HR_WARNING_LOW = 55
HR_CRITICAL_HIGH = 120
HR_CRITICAL_LOW = 40

SPO2_WARNING = 94
SPO2_CRITICAL = 90

TEMP_WARNING_HIGH = 38.0
TEMP_CRITICAL_HIGH = 39.0
TEMP_CRITICAL_LOW = 35.0

# Blood Pressure (mmHg) — JNC8 / AHA Clinical Guidelines
BP_SYS_WARNING = 140      # Stage 1 Hypertension
BP_SYS_CRITICAL = 180     # Hypertensive Crisis
BP_SYS_LOW = 90           # Hypotension
BP_DIA_WARNING = 90       # Stage 1 Hypertension
BP_DIA_CRITICAL = 120     # Hypertensive Crisis
BP_DIA_LOW = 60           # Hypotension

AIR_QUALITY_WARNING = 150   # PPM
AIR_QUALITY_CRITICAL = 300  # PPM

# ── Alert Settings ───────────────────────────────────────
ALERT_COOLDOWN_SECONDS = 30          # Min time between same alert for same patient
SUSTAINED_READINGS_REQUIRED = 2      # Consecutive abnormal readings before alert
PATIENT_OFFLINE_TIMEOUT = 30         # Seconds before marking offline

# ── Mock Mode ────────────────────────────────────────────
MOCK_PATIENT_COUNT = 1
MOCK_INTERVAL_SECONDS = 3
MOCK_CRITICAL_PROBABILITY = 0.02     # 2% chance of critical event
SINGLE_PATIENT_MODE = True           # Only 1 wearable in real setup

# ── Demo Patients ────────────────────────────────────────
# The single real patient wearing the device
PRIMARY_PATIENT = {"id": "P_01", "name": "Test Patient", "age": 72, "village": "Hanamkonda", "lat": 18.0539, "lng": 79.5357, "conditions": ["Diabetes", "Hypertension"]}

DEMO_PATIENTS = [
    PRIMARY_PATIENT,
]

# ── Pill Dispenser (4 slots, 1 servo by rotation angle) ──
PILL_SLOTS = [
    {"slot": 1, "label": "Morning",   "time": "08:00 AM", "angle": 0},
    {"slot": 2, "label": "Afternoon", "time": "01:00 PM", "angle": 60},
    {"slot": 3, "label": "Evening",   "time": "06:00 PM", "angle": 120},
    {"slot": 4, "label": "Night",     "time": "10:00 PM", "angle": 180},
]
SERVO_HOME_ANGLE = 180  # Servo resting position (closed)
