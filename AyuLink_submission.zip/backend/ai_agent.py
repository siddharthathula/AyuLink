"""
AyuLink AI Medical Agent — Groq-Powered Triage + Mental Health
Correlates vitals + environment + compliance + mental health distress.
Supports runtime API key swap, cooldown-based alert-only triggers.
"""
import asyncio, json, os, time, re
from dataclasses import dataclass, field
from typing import Optional
from groq import AsyncGroq
from dotenv import load_dotenv

load_dotenv()

GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
AI_COOLDOWN_SECONDS = 60  # increased to stop token spam
MAX_TOKENS = 200

# Mental health distress keywords
DISTRESS_KEYWORDS = re.compile(
    r"\b(suicide|kill myself|end it|hopeless|worthless|can't go on|"
    r"nobody cares|give up|hurt myself|self.?harm|depressed|anxious|"
    r"panic|scared|lonely|crying|overwhelmed|stressed|despair)\b",
    re.IGNORECASE
)

HELPLINES = {
    "en": "iCall: 9152987821 | Vandrevala: 1860-2662-345 | KIRAN: 1800-599-0019",
    "hi": "iCall: 9152987821 | वंद्रेवाला: 1860-2662-345 | किरण: 1800-599-0019",
    "te": "iCall: 9152987821 | వంద్రేవాలా: 1860-2662-345 | కిరణ్: 1800-599-0019",
}


@dataclass
class AgentInsight:
    patient_id: str
    patient_name: str
    severity: str
    trigger: str
    headline: str
    detail: str
    action: str
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in
                ["patient_id","patient_name","severity","trigger","headline","detail","action","timestamp"]}


class AyuAgent:
    def __init__(self, api_key: str = ""):
        self.api_key = api_key or os.getenv("GROQ_API_KEY", "")
        if not self.api_key:
            raise ValueError("GROQ_API_KEY not set!")
        self.client = AsyncGroq(api_key=self.api_key)
        self._cooldowns: dict[str, float] = {}
        self.insights: list[AgentInsight] = []
        print(f"[AyuAgent] ✓ Groq initialized (model: {GROQ_MODEL})")

    def update_api_key(self, new_key: str):
        """Hot-swap API key at runtime."""
        self.api_key = new_key
        self.client = AsyncGroq(api_key=new_key)
        print(f"[AyuAgent] API key updated")

    def _on_cooldown(self, patient_id: str, trigger: str) -> bool:
        key = f"{patient_id}:{trigger}"
        now = time.time()
        if key in self._cooldowns and (now - self._cooldowns[key]) < AI_COOLDOWN_SECONDS:
            return True
        self._cooldowns[key] = now
        return False

    @staticmethod
    def detect_distress(text: str) -> bool:
        return bool(DISTRESS_KEYWORDS.search(text))

    async def mental_health_response(self, message: str, language: str = "en") -> dict:
        """Generate empathetic mental health first-aid response."""
        lang_map = {"en": "English", "hi": "Hindi", "te": "Telugu"}
        helpline = HELPLINES.get(language, HELPLINES["en"])

        prompt = (
            f"A user sent: \"{message}\"\n"
            "They may be in emotional distress. As a mental health first-aid bot:\n"
            "1. Acknowledge their feelings with empathy\n"
            "2. Provide 1-2 evidence-based coping techniques\n"
            "3. Gently encourage professional help\n"
            f"Include this helpline info: {helpline}\n"
            f"Respond in {lang_map.get(language, 'English')}. Keep under 4 sentences."
        )
        try:
            r = await self.client.chat.completions.create(
                model=GROQ_MODEL,
                messages=[
                    {"role": "system", "content": "You are a compassionate mental health first-aid assistant. Never diagnose. Always recommend professional help. Be warm and non-judgmental."},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=250, temperature=0.6,
            )
            return {"ok": True, "reply": r.choices[0].message.content, "is_distress": True, "helplines": helpline}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    async def analyze(self, *, patient_id: str, patient_name: str, age: int,
                      conditions: list[str], hr: int, spo2: int, temp: float,
                      pill_slot1: bool, pill_slot2: bool, pill_slot3: bool, pill_slot4: bool,
                      air_ppm: int, air_aqi: str, flame: bool,
                      sos: bool, fall: bool, trigger: str, severity: str) -> Optional[AgentInsight]:
        if self._on_cooldown(patient_id, trigger):
            return None

        slots = [("Morning", pill_slot1), ("Afternoon", pill_slot2),
                 ("Evening", pill_slot3), ("Night", pill_slot4)]
        missed = [s[0] for s in slots if not s[1]]
        taken = [s[0] for s in slots if s[1]]

        flags = []
        if sos: flags.append("SOS activated")
        if fall: flags.append("Fall detected")
        if flame: flags.append("FIRE detected")

        user_prompt = (
            f"PATIENT: {patient_name}, Age {age}, Conditions: {', '.join(conditions) or 'None'}\n"
            f"TRIGGER: {trigger} ({severity.upper()})\n"
            f"FLAGS: {', '.join(flags) or 'None'}\n"
            f"VITALS: HR {hr}bpm, SpO2 {spo2}%, Temp {temp}°C\n"
            f"ENV: Air {air_ppm}PPM ({air_aqi}), Flame: {'YES' if flame else 'No'}\n"
            f"MEDS: Taken={', '.join(taken) or 'NONE'}, Missed={', '.join(missed) or 'None'}\n"
            "Respond ONLY JSON: {\"headline\":\"...\",\"detail\":\"...\",\"action\":\"...\"}"
        )

        try:
            r = await self.client.chat.completions.create(
                model=GROQ_MODEL,
                messages=[
                    {"role": "system", "content": "You are AyuLink Medical Triage Agent for eldercare IoT. Correlate all signals. Respond in strict JSON with keys: headline, detail, action. Be precise and concise."},
                    {"role": "user", "content": user_prompt},
                ],
                max_tokens=MAX_TOKENS, temperature=0.4,
                response_format={"type": "json_object"},
            )
            parsed = json.loads(r.choices[0].message.content)
            insight = AgentInsight(
                patient_id=patient_id, patient_name=patient_name,
                severity=severity, trigger=trigger,
                headline=parsed.get("headline", "AI insight"),
                detail=parsed.get("detail", ""),
                action=parsed.get("action", ""),
            )
            self.insights.append(insight)
            if len(self.insights) > 50:
                self.insights = self.insights[-50:]
            return insight
        except Exception as e:
            print(f"[AyuAgent] Error: {e}")
            return None

    def get_recent_insights(self, n: int = 20) -> list[dict]:
        return [i.to_dict() for i in reversed(self.insights[-n:])]

    def clear_insights(self):
        self.insights.clear()
